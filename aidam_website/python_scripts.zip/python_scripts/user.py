# this file stores usernames and passwords for the database
username="jstrik"
password="strik"
name_of_user="Justin"
